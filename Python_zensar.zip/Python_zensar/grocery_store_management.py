import mysql.connector
from datetime import datetime

# Database configuration
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "root",
    "database": "grocery_store"
}

# Function to connect to the database
def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

# Function to display the menu
def display_menu():
    print("\n--- Grocery Store Management System ---")
    print("1. Add Item to Inventory")
    print("2. Update Item in Inventory")
    print("3. Delete Item from Inventory")
    print("4. View Inventory")
    print("5. Place Order")
    print("6. View Orders")
    print("7. Exit")

# Function to add an item to inventory
def add_item():
    name = input("Enter item name: ")
    category = input("Enter category: ")
    price = float(input("Enter price: "))
    stock = int(input("Enter stock: "))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO items (name, category, price, stock) VALUES (%s, %s, %s, %s)", (name, category, price, stock))
    conn.commit()
    print(f"Item '{name}' added successfully!")
    cursor.close()
    conn.close()

# Function to update an item in inventory
def update_item():
    item_id = int(input("Enter item ID to update: "))
    name = input("Enter new name: ")
    category = input("Enter new category: ")
    price = float(input("Enter new price: "))
    stock = int(input("Enter new stock: "))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE items SET name=%s, category=%s, price=%s, stock=%s WHERE item_id=%s", (name, category, price, stock, item_id))
    conn.commit()
    print(f"Item ID {item_id} updated successfully!")
    cursor.close()
    conn.close()

# Function to delete an item from inventory
def delete_item():
    item_id = int(input("Enter item ID to delete: "))

    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM items WHERE item_id=%s", (item_id,))
    conn.commit()
    print(f"Item ID {item_id} deleted successfully!")
    cursor.close()
    conn.close()

# Function to view inventory
def view_inventory():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM items")
    items = cursor.fetchall()
    print("\n--- Inventory ---")
    for item in items:
        print(f"ID: {item['item_id']}, Name: {item['name']}, Category: {item['category']}, Price: {item['price']}, Stock: {item['stock']}")
    cursor.close()
    conn.close()

# Function to place an order
def place_order():
    customer_name = input("Enter customer name: ")
    total_price = 0
    order_items = []

    while True:
        item_id = int(input("Enter item ID to add to order (0 to finish): "))
        if item_id == 0:
            break
        quantity = int(input("Enter quantity: "))

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM items WHERE item_id=%s", (item_id,))
        item = cursor.fetchone()

        if item:
            if item['stock'] >= quantity:
                order_items.append((item_id, quantity, item['price'] * quantity))
                total_price += item['price'] * quantity
                cursor.execute("UPDATE items SET stock=stock-%s WHERE item_id=%s", (quantity, item_id))
            else:
                print(f"Not enough stock for item: {item['name']}")
        else:
            print("Invalid item ID.")
        conn.commit()
        cursor.close()
        conn.close()

    if order_items:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO orders (customer_name, total_price) VALUES (%s, %s)", (customer_name, total_price))
        order_id = cursor.lastrowid

        for item_id, quantity, price in order_items:
            cursor.execute("INSERT INTO order_details (order_id, item_id, quantity, price) VALUES (%s, %s, %s, %s)", (order_id, item_id, quantity, price))

        conn.commit()
        print(f"Order placed successfully! Order ID: {order_id}")
        cursor.close()
        conn.close()

# Function to view orders
def view_orders():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM orders")
    orders = cursor.fetchall()
    print("\n--- Orders ---")
    for order in orders:
        print(f"Order ID: {order['order_id']}, Customer: {order['customer_name']}, Date: {order['order_date']}, Total: {order['total_price']}")
    cursor.close()
    conn.close()

# Main function
def main():
    while True:
        display_menu()
        choice = int(input("Enter your choice: "))
        if choice == 1:
            add_item()
        elif choice == 2:
            update_item()
        elif choice == 3:
            delete_item()
        elif choice == 4:
            view_inventory()
        elif choice == 5:
            place_order()
        elif choice == 6:
            view_orders()
        elif choice == 7:
            print("Exiting...")
            break
        else:
            print("Invalid choice, please try again.")

if __name__ == "__main__":
    main()
