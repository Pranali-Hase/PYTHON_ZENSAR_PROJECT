CREATE DATABASE grocery_store;

USE grocery_store;

-- Table for storing items
CREATE TABLE items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    stock INT NOT NULL
);

-- Table for storing customer orders
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_price DECIMAL(10, 2) NOT NULL
);

-- Table for order details
CREATE TABLE order_details (
    order_detail_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    item_id INT,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (item_id) REFERENCES items(item_id)
);

-- Insert sample data into items table
INSERT INTO items (name, category, price, stock) VALUES
('Apple', 'Fruits', 2.50, 50),
('Banana', 'Fruits', 1.20, 100),
('Carrot', 'Vegetables', 1.00, 30),
('Milk', 'Dairy', 3.00, 20),
('Bread', 'Bakery', 2.00, 40);

-- Insert sample data into orders table
INSERT INTO orders (customer_name, total_price) VALUES
('John Doe', 10.00),
('Jane Smith', 25.00),
('Michael Brown', 15.50),
('Emily Davis', 30.00);

-- Insert sample data into order_details table
INSERT INTO order_details (order_id, item_id, quantity, price) VALUES
(1, 1, 4, 10.00),
(2, 2, 5, 6.00),
(3, 3, 2, 2.00),
(4, 4, 3, 9.00);

