import mysql.connector
from mysql.connector import Error

# Database configuration
DB_CONFIG = {
    "host": "localhost",       # Replace with your database host
    "user": "root",            # Replace with your MySQL username
    "password": "root",        # Replace with your MySQL password
    "database": "grocery_store"  # Replace with your database name
}

def get_db_connection():
    """
    Establish and return a connection to the database.
    Returns:
        mysql.connector.connection: The database connection object.
    Raises:
        Exception: If a connection error occurs.
    """
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        if conn.is_connected():
            print("Database connection established successfully.")
            return conn
    except Error as e:
        print(f"Error connecting to the database: {e}")
        raise
